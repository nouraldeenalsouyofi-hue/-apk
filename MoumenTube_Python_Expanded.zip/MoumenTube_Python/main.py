import flet as ft
import asyncio, json, os, re, time, uuid, urllib.parse, urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

APP_NAME = "مؤمن تيوب"
BERRY = "#741B35"
BERRY_DARK = "#4D1025"
BG = "#FFF9FA"
CARD = "#FFFFFF"
TEXT = "#24151B"
MUTED = "#806D74"
DATA_FILE = Path("moumen_data.json")

# Configure these as GitHub Actions secrets or environment variables.
SUPABASE_URL = os.getenv("MOUMEN_SUPABASE_URL", "").rstrip("/")
SUPABASE_KEY = os.getenv("MOUMEN_SUPABASE_KEY", "")

BLOCKED_TERMS = [
    "مسلسل", "دفوف", "شفا", "غزل وتيم", "أطفال", "اطفال", "طفل",
    "كرتون", "أغاني أطفال", "اغاني اطفال", "رسوم متحركة للأطفال",
    "العاب اطفال", "ألعاب أطفال", "تعليم الأطفال", "تعليم الاطفال",
    "قناة أطفال", "قناة اطفال", "nursery rhymes", "kids cartoon", "for kids"
]
ALLOWED_TERMS = [
    "بدون موسيقى", "بدون", "بدون إيقاع", "بدون ايقاع", "غزة", "غزه",
    "محمد شمس الدين", "عثمان الخميس", "فتاوى", "العدوي", "حسن الحسيني",
    "مؤمن تيوب", "اسلامي", "إسلامي", "ديني", "مشعل", "عبد السلام شويعر",
    "شريعة", "شريعه", "حديث", "قرآن", "قران", "سنة", "سنه", "سلفي",
    "سلفية", "سلفيه", "مداخلة", "سورة", "القارئ", "ابن القيم", "ابن الجوزي",
    "ابن تيمية", "الأزهر", "الحرم", "المكي", "المدني", "المسجد", "النبوي",
    "الشريف", "السعودية", "المدينة", "المدينه", "أحمد النفيس", "احمد النفيس",
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف",
    "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر",
    "النحل", "الإسراء", "الكهف", "مريم", "طه", "الأنبياء", "الحج", "المؤمنون",
    "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "الزمر",
    "غافر", "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف",
    "محمد", "الفتح", "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر",
    "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف",
    "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم",
    "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر", "القيامة",
    "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس", "التكوير", "الانفطار",
    "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر",
    "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر",
    "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة",
    "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر", "المسد",
    "الإخلاص", "الفلق", "الناس"
]
CATEGORIES = ["الكل", "القرآن", "التلاوات", "التفسير", "الحديث", "الدروس",
              "الخطب", "الأناشيد", "أطفال", "كرتون إسلامي", "قصص الأنبياء",
              "تعليم القرآن", "أذكار", "رمضان", "سيرة نبوية", "دعاء", "متنوع"]

PIPED = [
    "https://pipedapi.kavin.rocks", "https://pipedapi.leptons.xyz",
    "https://pipedapi.nosebs.ru", "https://pipedapi-libre.kavin.rocks",
    "https://piped-api.privacy.com.de", "https://pipedapi.adminforge.de",
    "https://api.piped.yt", "https://pipedapi.drgns.space",
    "https://pipedapi.owo.si", "https://pipedapi.ducks.party",
    "https://piped-api.codespace.cz", "https://pipedapi.reallyaweso.me",
    "https://api.piped.private.coffee"
]
INVIDIOUS = ["https://inv.nadeko.net", "https://invidious.nerdvpn.de",
             "https://yt.chocolatemoo53.com", "https://invidious.tiekoetter.com"]

LIVE_CHANNELS = [
    ("قناة القرآن الكريم — مكة المكرمة", "UCos52azQNBgW63_9uDJoPDA"),
    ("قناة السنة النبوية — المدينة المنورة", "UCROKYPep-UuODNwyipe6JMw")
]
LIVE_SEARCHES = [
    ("بث الشيخ زين خير الله", r"زين\s*خير\s*الله"),
    ("بث الشيخ محمد بن شمس الدين", r"محمد\s*(?:بن\s*)?شمس\s*الدين|شمس\s*الدين"),
    ("بث الشيخ عاصم الحكيم", r"assim\s*(?:al\s*)?hakeem|عاصم\s*(?:بن\s*)?الحكيم")
]

def norm(value):
    s = str(value or "").lower()
    s = s.translate(str.maketrans({"أ":"ا","إ":"ا","آ":"ا","ى":"ي","ة":"ه"}))
    return re.sub(r"[\u064b-\u065fـ]", "", re.sub(r"\s+", " ", s)).strip()

def title_allowed(title):
    t = norm(title)
    return not any(norm(w) in t for w in BLOCKED_TERMS) and any(norm(w) in t for w in ALLOWED_TERMS)

def youtube_id(url):
    try:
        u = urllib.parse.urlparse(str(url).strip())
        host = (u.hostname or "").lower()
        if host.endswith("youtu.be"):
            return u.path.strip("/").split("/")[0]
        if "youtube.com" in host:
            q = urllib.parse.parse_qs(u.query)
            if q.get("v"): return q["v"][0]
            m = re.search(r"/(?:shorts|embed|live)/([A-Za-z0-9_-]{6,})", u.path)
            if m: return m.group(1)
    except Exception:
        pass
    return ""

def http_json(url, timeout=9):
    req = urllib.request.Request(url, headers={"Accept":"application/json", "User-Agent":"MoumenTube/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        if "json" not in response.headers.get("Content-Type", "").lower():
            raise ValueError("مصدر البحث لم يُرجع JSON")
        return json.loads(response.read().decode("utf-8", "replace"))

def search_instance(instance, query, piped=True):
    if piped:
        url = instance + "/search?" + urllib.parse.urlencode({"q":query, "filter":"all"})
    else:
        url = instance + "/api/v1/search?" + urllib.parse.urlencode({"q":query,"type":"video","sort":"relevance","page":"1","hl":"ar"})
    data = http_json(url)
    if isinstance(data, list): return {"items":data}
    if isinstance(data, dict):
        for k in ("items","results","videos"):
            if isinstance(data.get(k), list): return {**data, "items":data[k]}
    return {"items":[]}

def normalize_result(x):
    raw_id = str(x.get("videoId") or x.get("id") or "")
    raw_url = str(x.get("url") or x.get("link") or x.get("videoUrl") or "")
    vid = raw_id if re.fullmatch(r"[A-Za-z0-9_-]{6,}", raw_id) else youtube_id(raw_url)
    title = str(x.get("title") or x.get("name") or "").strip()
    if not vid or not title: return None
    duration = x.get("duration") or x.get("lengthSeconds") or 0
    try: duration = int(duration)
    except Exception: duration = 0
    is_short = "/shorts/" in raw_url.lower() or "short" in str(x.get("type","")).lower() or (0 < duration <= 60)
    return {"id":vid,"title":title,"channel":str(x.get("uploaderName") or x.get("uploader") or x.get("author") or x.get("channelName") or x.get("channel") or ""),
            "url":"https://www.youtube.com/watch?v="+vid,"kind":"short" if is_short else "video",
            "thumbnail":"https://i.ytimg.com/vi/"+vid+"/hqdefault.jpg"}

def youtube_search(query):
    query = " ".join(query.split())
    if not query: return []
    suffixes = ["بدون موسيقى","بدون إيقاع","بدون","قرآن","عثمان الخميس","فتاوى","ابن القيم","حديث","سورة","القارئ","أحمد النفيس","محمد شمس الدين"]
    queries = [query] + [query+" "+s for s in suffixes]
    providers = [(x, True) for x in PIPED] + [(x, False) for x in INVIDIOUS]
    with ThreadPoolExecutor(max_workers=12) as pool:
        futures = {pool.submit(search_instance, host, queries[0], piped): (host,piped) for host,piped in providers}
        selected = None
        for f in as_completed(futures):
            try:
                data = f.result()
                if isinstance(data.get("items"), list):
                    selected = (futures[f][0], futures[f][1], data)
                    break
            except Exception:
                continue
        for f in futures:
            if not f.done(): f.cancel()
    if not selected: raise RuntimeError("تعذر الوصول إلى مصادر البحث العامة حالياً")
    host, piped, first = selected
    raw = list(first.get("items", []))
    # Search a few approved discovery suffixes through the responsive mirror.
    for start in range(0, min(len(queries)-1, 6), 3):
        with ThreadPoolExecutor(max_workers=3) as pool:
            fs = [pool.submit(search_instance, host, q, piped) for q in queries[start+1:start+4]]
            for f in as_completed(fs):
                try: raw.extend(f.result().get("items", []))
                except Exception: pass
    results, seen = [], set()
    for x in raw:
        if not isinstance(x, dict): continue
        item = normalize_result(x)
        if item and item["id"] not in seen and title_allowed(item["title"]):
            seen.add(item["id"]); results.append(item)
        if len(results) >= 60: break
    return results

def load_data():
    try:
        obj = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        if isinstance(obj, dict): return obj
    except Exception: pass
    return {"items":[], "likes":[], "saved":[], "history":[], "owner_password":"2011",
            "preferences":[], "dhikr_enabled":False}

def save_data(data):
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def cloud_request(method, table="content", payload=None, query=""):
    if not (SUPABASE_URL and SUPABASE_KEY): raise RuntimeError("لم تُضبط مفاتيح Supabase في إعدادات البناء")
    url = f"{SUPABASE_URL}/rest/v1/{table}" + (("?"+query) if query else "")
    prefer = "resolution=merge-duplicates,return=representation" if method == "POST" else "return=representation"
    headers = {"apikey":SUPABASE_KEY,"Authorization":"Bearer "+SUPABASE_KEY,
               "Content-Type":"application/json","Prefer":prefer}
    body = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=14) as res:
        raw = res.read().decode("utf-8","replace")
        return json.loads(raw) if raw else []

def cloud_row(item):
    keys = ("id","kind","title","channel","cat","text","url","likes","comments","created","views")
    return {k:item.get(k) for k in keys if k in item}

def main(page: ft.Page):
    data = load_data()
    page.title = APP_NAME
    page.rtl = True
    page.padding = 0
    page.spacing = 0
    page.bgcolor = BG
    page.theme = ft.Theme(color_scheme_seed=BERRY, use_material3=True)
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window_min_width, page.window_min_height = 360, 640

    tab = {"name":"الرئيسية"}
    search_box = ft.TextField(hint_text="ابحث في مؤمن تيوب ويوتيوب...", prefix_icon=ft.Icons.SEARCH,
        border=ft.InputBorder.NONE, filled=True, bgcolor="#F4E9ED", border_radius=24,
        text_size=14, height=48, expand=True)
    content = ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=12)
    cloud_label = ft.Text("السحابة: لم يتم الفحص", color=MUTED, size=11)
    search_results = []
    live_results = []
    owner_mode = {"on":False}
    current_item = {"id":None}
    dhikr_timer = {"on":bool(data.get("dhikr_enabled"))}

    def toast(msg):
        page.snack_bar = ft.SnackBar(content=ft.Text(msg, text_align=ft.TextAlign.RIGHT))
        page.snack_bar.open = True
        page.update()

    def persist():
        save_data(data)

    def card(item, remote=False):
        vid = item.get("id","")
        kind = item.get("kind","video")
        return ft.Container(
            bgcolor=CARD, border_radius=16, padding=12,
            content=ft.Column([
                ft.Container(height=154, bgcolor="#F2E7EB", border_radius=12,
                    alignment=ft.alignment.center,
                    content=ft.Image(src=item.get("thumbnail") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                                    fit=ft.ImageFit.COVER, border_radius=12)),
                ft.Text(item.get("title",""), color=TEXT, weight=ft.FontWeight.BOLD, size=14),
                ft.Text(item.get("channel",""), color=MUTED, size=11),
                ft.Row([
                    ft.FilledButton("مشاهدة", icon=ft.Icons.PLAY_ARROW,
                        on_click=lambda e, x=item: play_item(x),
                        style=ft.ButtonStyle(bgcolor=BERRY, color="white")),
                    ft.OutlinedButton("مشاركة", icon=ft.Icons.SHARE,
                        on_click=lambda e, x=item: share_item(x)),
                    ft.IconButton(ft.Icons.BOOKMARK if vid in data["saved"] else ft.Icons.BOOKMARK_BORDER,
                        icon_color=BERRY, tooltip="حفظ", on_click=lambda e, x=item: toggle_saved(x)),
                ], wrap=True)
            ], spacing=7)
        )

    def local_card(item):
        vid = item.get("id")
        controls = [
            ft.Text(item.get("title",""), color=TEXT, weight=ft.FontWeight.BOLD, size=15),
            ft.Text((item.get("channel","")+" · "+item.get("cat","")), color=MUTED, size=11),
            ft.Text(item.get("text",""), color=TEXT, size=13) if item.get("kind")=="post" else ft.Container(),
            ft.Row([
                ft.TextButton(f"♥ {item.get('likes',0)}", on_click=lambda e,x=item: toggle_like(x)),
                ft.TextButton(f"💬 {len(item.get('comments',[]))}", on_click=lambda e,x=item: open_comments(x)),
                ft.TextButton("مشاهدة", on_click=lambda e,x=item: play_item(x)) if item.get("kind")!="post" else ft.TextButton("التعليقات", on_click=lambda e,x=item: open_comments(x)),
                ft.TextButton("حفظ", on_click=lambda e,x=item: toggle_saved(x)),
            ], wrap=True)
        ]
        if owner_mode["on"]:
            controls.append(ft.Row([
                ft.TextButton("تعديل", on_click=lambda e,x=item: edit_item(x)),
                ft.TextButton("حذف", on_click=lambda e,x=item: delete_item(x))
            ]))
        return ft.Container(bgcolor=CARD, border_radius=16, padding=14, content=ft.Column(controls, spacing=6))

    def section(title, items):
        return [ft.Text(title, size=18, weight=ft.FontWeight.BOLD, color=TEXT)] + (
            [card(x) if x.get("kind") in ("video","short") else local_card(x) for x in items]
            if items else [empty("لا يوجد محتوى هنا بعد", "اضغط زر + لإضافة أول عنصر")]
        )

    def empty(title, subtitle, icon=ft.Icons.VIDEO_LIBRARY_OUTLINED):
        return ft.Container(padding=24, bgcolor="#F7EEF1", border_radius=18,
            content=ft.Column([ft.Icon(icon,size=42,color=BERRY),ft.Text(title,weight=ft.FontWeight.BOLD,color=TEXT),
                ft.Text(subtitle,color=MUTED,size=12,text_align=ft.TextAlign.CENTER)],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=8))

    def play_item(item):
        url = item.get("url") or ("https://www.youtube.com/watch?v="+item.get("id",""))
        current_item["id"] = item.get("id")
        if item.get("kind") == "post":
            open_comments(item); return
        # Flet's native APK opens YouTube through the Android URL handler.
        # This avoids pretending an embedded WebView is present when it isn't.
        page.launch_url(url)

    def share_item(item):
        url = item.get("url") or ("https://www.youtube.com/watch?v="+item.get("id",""))
        page.set_clipboard(url)
        toast("تم نسخ رابط المشاركة")

    def toggle_saved(item):
        ident = item.get("id")
        if ident in data["saved"]: data["saved"].remove(ident)
        else: data["saved"].append(ident)
        persist(); toast("تم تحديث المحفوظات"); render()

    def toggle_like(item):
        item["likes"] = max(0,int(item.get("likes",0))+1)
        if item.get("id") not in data["likes"]: data["likes"].append(item.get("id"))
        persist(); render()

    def open_comments(item):
        comments = item.setdefault("comments",[])
        comment_input = ft.TextField(label="اكتب تعليقك", multiline=True, min_lines=1, max_lines=3)
        def send(e):
            if not (comment_input.value or "").strip(): return
            comments.append({"name":"مستخدم","text":comment_input.value.strip(),"created":int(time.time()*1000)})
            persist(); dlg.open=False; page.update(); render(); toast("تم حفظ التعليق")
        dlg = ft.AlertDialog(title=ft.Text("التعليقات"),
            content=ft.Column([ft.Text(c.get("name","مستخدم"),weight=ft.FontWeight.BOLD) for c in comments[-10:]] +
                [ft.Text(c.get("text","")) for c in comments[-10:]] + [comment_input], tight=True, scroll=ft.ScrollMode.AUTO),
            actions=[ft.TextButton("إغلاق",on_click=lambda e:close_dialog(dlg)),ft.FilledButton("إرسال",on_click=send)])
        page.overlay.append(dlg); dlg.open=True; page.update()

    def close_dialog(dlg):
        dlg.open=False; page.update()

    async def search_click(e=None):
        q=(search_box.value or "").strip()
        if not q: toast("اكتب عبارة البحث أولاً"); return
        content.controls=[empty("جاري البحث", "نبحث في مصادر YouTube العامة ونطبق قائمة السماح والمنع", ft.Icons.SEARCH)]
        page.update()
        try:
            found=await asyncio.to_thread(youtube_search,q)
            search_results.clear(); search_results.extend(found)
            content.controls=[ft.Text(f"نتائج البحث من YouTube · {len(found)}",size=18,weight=ft.FontWeight.BOLD,color=TEXT)]
            if found:
                shorts=[x for x in found if x["kind"]=="short"]
                longs=[x for x in found if x["kind"]!="short"]
                if shorts: content.controls += [ft.Text("مقاطع Shorts",weight=ft.FontWeight.BOLD,color=BERRY)] + [card(x,True) for x in shorts]
                if longs: content.controls += [ft.Text("الفيديوهات الطويلة",weight=ft.FontWeight.BOLD,color=BERRY)] + [card(x,True) for x in longs]
            else: content.controls.append(empty("لا توجد نتائج مناسبة", "العنوان يجب أن يتضمن عبارة مسموحة وألا يحتوي أي كلمة محظورة"))
        except Exception as ex:
            content.controls=[empty("تعذر البحث حالياً",str(ex),ft.Icons.CLOUD_OFF)]
        page.update()

    def add_content(e=None):
        kind = ft.Dropdown(label="نوع المحتوى", value="video", options=[
            ft.dropdown.Option("video","فيديو"),ft.dropdown.Option("short","Shorts"),ft.dropdown.Option("post","منشور")])
        title = ft.TextField(label="العنوان")
        channel = ft.TextField(label="اسم القناة")
        cat = ft.Dropdown(label="التصنيف", value="متنوع", options=[ft.dropdown.Option(x) for x in CATEGORIES[1:]])
        url = ft.TextField(label="رابط YouTube", text_align=ft.TextAlign.LEFT)
        body = ft.TextField(label="النص / الوصف", multiline=True, min_lines=2, max_lines=4)
        status = ft.Text("",color=MUTED,size=11)
        def publish(ev):
            name=(title.value or "").strip(); link=(url.value or "").strip()
            if not name: toast("اكتب العنوان أولاً"); return
            if kind.value!="post" and not youtube_id(link): toast("رابط YouTube غير صالح"); return
            if kind.value!="post" and not title_allowed(name):
                toast("رفضت الفلترة هذا العنوان: لا يطابق قائمة السماح أو يحتوي كلمة محظورة"); return
            ident=youtube_id(link) if kind.value!="post" else str(uuid.uuid4())
            item={"id":ident,"kind":kind.value,"title":name,"channel":(channel.value or "").strip(),
                  "cat":cat.value,"text":(body.value or "").strip(),"url":link,"likes":0,"comments":[],
                  "created":int(time.time()*1000),"views":0}
            data["items"].insert(0,item); persist(); dlg.open=False; page.update(); render()
            toast("تمت الإضافة محلياً، جارٍ محاولة المزامنة")
            page.run_thread(lambda: cloud_upsert(item))
        dlg=ft.AlertDialog(title=ft.Text("إضافة محتوى"),
            content=ft.Column([kind,title,channel,cat,url,body,status],tight=True,scroll=ft.ScrollMode.AUTO,width=330),
            actions=[ft.TextButton("إلغاء",on_click=lambda e:close_dialog(dlg)),ft.FilledButton("نشر",on_click=publish,style=ft.ButtonStyle(bgcolor=BERRY))])
        page.overlay.append(dlg); dlg.open=True; page.update()

    def cloud_upsert(item):
        try:
            row=cloud_row(item)
            cloud_request("POST","content",row,"on_conflict=id")
            cloud_label.value="السحابة: تم حفظ العنصر ✓"; cloud_label.color="#27804A"
        except Exception as ex:
            cloud_label.value="السحابة: محلي فقط — "+str(ex)[:100]; cloud_label.color=MUTED
        page.update()

    async def sync_cloud(e=None):
        cloud_label.value="السحابة: جارٍ المزامنة..."; page.update()
        try:
            rows=await asyncio.to_thread(cloud_request,"GET","content",None,"select=*&order=created.desc")
            if isinstance(rows,list):
                local_flags={x["id"]:x for x in data["items"]}
                merged=[]
                for row in rows:
                    row.setdefault("comments",[]); row.setdefault("likes",0)
                    if row.get("id") in local_flags:
                        row["saved"]=local_flags[row["id"]].get("saved",False)
                    merged.append(row)
                data["items"]=merged; persist()
            cloud_label.value=f"السحابة: متصلة · {len(data['items'])} عنصر"; cloud_label.color="#27804A"
            toast("اكتملت مزامنة المحتوى")
        except Exception as ex:
            cloud_label.value="السحابة: غير متاحة — "+str(ex)[:100]; cloud_label.color="#A14B4B"
            toast("تعذرت المزامنة؛ بقي المحتوى المحلي محفوظاً")
        render(); page.update()

    def edit_item(item):
        title=ft.TextField(label="العنوان",value=item.get("title",""))
        channel=ft.TextField(label="القناة",value=item.get("channel",""))
        url=ft.TextField(label="الرابط",value=item.get("url",""))
        body=ft.TextField(label="النص",value=item.get("text",""),multiline=True)
        def save_edit(e):
            item.update({"title":title.value,"channel":channel.value,"url":url.value,"text":body.value})
            persist(); dlg.open=False; page.update(); render()
            page.run_thread(lambda:cloud_upsert(item))
        dlg=ft.AlertDialog(title=ft.Text("تعديل المحتوى"),content=ft.Column([title,channel,url,body],tight=True,width=320),
            actions=[ft.TextButton("إلغاء",on_click=lambda e:close_dialog(dlg)),ft.FilledButton("حفظ",on_click=save_edit)])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def delete_item(item):
        def yes(e):
            data["items"]=[x for x in data["items"] if x.get("id")!=item.get("id")]
            persist(); dlg.open=False; page.update(); render()
            if SUPABASE_URL and SUPABASE_KEY:
                page.run_thread(lambda: cloud_delete(item["id"]))
        dlg=ft.AlertDialog(title=ft.Text("حذف المحتوى؟"),content=ft.Text("سيُحذف من هذه النسخة المحلية، ومن السحابة إذا كانت متصلة."),
            actions=[ft.TextButton("إلغاء",on_click=lambda e:close_dialog(dlg)),ft.FilledButton("حذف",on_click=yes,style=ft.ButtonStyle(bgcolor=BERRY))])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def cloud_delete(ident):
        try: cloud_request("DELETE","content",None,"id=eq."+urllib.parse.quote(str(ident)))
        except Exception as ex: toast("تعذر الحذف السحابي: "+str(ex)[:90])

    def owner_login(e=None):
        pw=ft.TextField(label="كلمة مرور المالك",password=True,can_reveal_password=True)
        def enter(ev):
            if pw.value==(data.get("owner_password") or "2011"):
                owner_mode["on"]=True;dlg.open=False;page.update();render();toast("تم تفعيل وضع المالك")
            else: toast("كلمة المرور غير صحيحة")
        dlg=ft.AlertDialog(title=ft.Text("دخول المالك"),content=pw,
            actions=[ft.TextButton("إلغاء",on_click=lambda e:close_dialog(dlg)),ft.FilledButton("دخول",on_click=enter)])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def admin_panel(e=None):
        if not owner_mode["on"]: owner_login(); return
        newpw=ft.TextField(label="كلمة مرور جديدة",password=True)
        info=ft.Text("الإحصائيات المحلية: "+str(len(data["items"]))+" عنصر · "+
                     str(sum(len(x.get("comments",[])) for x in data["items"]))+" تعليق")
        def change_pw(ev):
            if len(newpw.value or "")<4: toast("كلمة المرور يجب أن تكون 4 أحرف على الأقل"); return
            data["owner_password"]=newpw.value;persist();toast("تم تغيير كلمة المرور على هذا الجهاز")
        dlg=ft.AlertDialog(title=ft.Text("إعدادات المالك"),
            content=ft.Column([info,cloud_label,newpw],tight=True,width=320),
            actions=[ft.TextButton("فحص/مزامنة السحابة",on_click=sync_cloud),
                     ft.TextButton("تغيير كلمة المرور",on_click=change_pw),
                     ft.TextButton("تسجيل خروج",on_click=lambda e:logout_owner(dlg))])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def logout_owner(dlg):
        owner_mode["on"]=False;close_dialog(dlg);render()

    async def live_check(e=None):
        content.controls=[empty("جارٍ فحص البثوث المباشرة","نبحث عن القنوات والبثوث النشطة",ft.Icons.LIVE_TV)];page.update()
        found=[{"name":n,"id":cid,"channel":True} for n,cid in LIVE_CHANNELS]
        def find_live(q, pattern):
            rx=re.compile(pattern,re.I)
            for host in PIPED[:8]:
                try:
                    d=search_instance(host,q,True)
                    for x in d.get("items",[]):
                        text=str(x.get("uploaderName") or x.get("uploader") or x.get("channel") or "")+" "+str(x.get("title") or "")
                        if str(x.get("type","")).lower()=="stream" and rx.search(text):
                            item=normalize_result(x)
                            if item: return {"name":item["title"],"id":item["id"],"channel":False}
                except Exception: continue
            return None
        results=await asyncio.gather(*[asyncio.to_thread(find_live,q,p) for q,p in LIVE_SEARCHES])
        found += [x for x in results if x]
        live_results.clear();live_results.extend(found)
        content.controls=[ft.Text("البثوث المباشرة",size=19,weight=ft.FontWeight.BOLD,color=TEXT)]
        for item in found:
            content.controls.append(ft.Container(bgcolor=CARD,padding=14,border_radius=14,
                content=ft.Row([ft.Icon(ft.Icons.CIRCLE,color="#D32F2F",size=12),
                    ft.Text(item["name"],expand=True,color=TEXT),
                    ft.FilledButton("مشاهدة",on_click=lambda ev,x=item:page.launch_url(
                        "https://www.youtube.com/channel/"+x["id"]+"/live" if x["channel"] else "https://www.youtube.com/watch?v="+x["id"]),
                        style=ft.ButtonStyle(bgcolor=BERRY,color="white"))])))
        if not found: content.controls.append(empty("لا يظهر بث نشط حالياً","جرّب التحقق مرة أخرى لاحقاً"))
        page.update()

    async def prayer_times(e=None):
        city=ft.TextField(label="المدينة",value="Kilis",text_align=ft.TextAlign.LEFT)
        result=ft.Column()
        async def fetch(ev):
            try:
                url="https://api.aladhan.com/v1/timingsByCity?"+urllib.parse.urlencode({"city":city.value,"country":"Türkiye","method":13})
                obj=await asyncio.to_thread(http_json,url)
                times=obj["data"]["timings"]
                result.controls=[ft.Text(f"{k}: {times[k]}",color=TEXT) for k in ["Fajr","Dhuhr","Asr","Maghrib","Isha"]]
            except Exception as ex: result.controls=[ft.Text("تعذر جلب المواقيت: "+str(ex),color="#A14B4B")]
            page.update()
        dlg=ft.AlertDialog(title=ft.Text("مواقيت الصلاة"),content=ft.Column([city,ft.FilledButton("عرض المواقيت",on_click=fetch),result],tight=True,width=310),
            actions=[ft.TextButton("إغلاق",on_click=lambda e:close_dialog(dlg))])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def adhkar(e=None):
        messages=["سبحان الله وبحمده، سبحان الله العظيم","أستغفر الله وأتوب إليه","لا إله إلا الله وحده لا شريك له","اللهم صل وسلم على نبينا محمد"]
        import random
        toast(random.choice(messages))

    def game(e=None):
        score={"n":0}
        label=ft.Text("النقاط: 0",size=18,weight=ft.FontWeight.BOLD,color=BERRY)
        car=ft.Text("🏎️",size=55)
        lane=ft.Text("       🚧              🚧",size=36)
        def move(ev):
            score["n"]+=1;label.value="النقاط: "+str(score["n"]);page.update()
        dlg=ft.AlertDialog(title=ft.Text("لعبة السيارات"),
            content=ft.Column([label,lane,car,ft.Text("اضغط على الطريق لتجاوز الحواجز وكسب النقاط",color=MUTED),
                ft.FilledButton("تحرك وتجاوز",on_click=move,style=ft.ButtonStyle(bgcolor=BERRY,color="white"))],tight=True,width=300),
            actions=[ft.TextButton("خروج",on_click=lambda e:close_dialog(dlg))])
        page.overlay.append(dlg);dlg.open=True;page.update()

    def render():
        name=tab["name"]
        items=sorted(data["items"],key=lambda x:x.get("created",0),reverse=True)
        content.controls=[]
        if name=="الرئيسية":
            content.controls=[
                ft.Container(padding=18,border_radius=18,
                    gradient=ft.LinearGradient(begin=ft.alignment.top_right,end=ft.alignment.bottom_left,colors=[BERRY,BERRY_DARK]),
                    content=ft.Column([ft.Text("محتوى هادف في مكان واحد",size=21,weight=ft.FontWeight.BOLD,color="white"),
                        ft.Text("قرآن وتلاوات ودروس ومحتوى نافع",color="#F8E9EE"),
                        ft.Row([ft.FilledButton("إضافة محتوى",on_click=add_content,style=ft.ButtonStyle(bgcolor="white",color=BERRY)),
                                ft.OutlinedButton("البثوث المباشرة",on_click=live_check,style=ft.ButtonStyle(color="white"))],wrap=True)])),
                ft.Text("أحدث الفيديوهات",size=18,weight=ft.FontWeight.BOLD,color=TEXT)
            ]
            content.controls += [local_card(x) for x in items[:8]] or [empty("مرحباً بك","أضف محتوى أو ابحث في YouTube")]
        elif name=="الفيديوهات":
            content.controls=section(name,[x for x in items if x.get("kind")=="video"])
        elif name=="Shorts":
            content.controls=section(name,[x for x in items if x.get("kind")=="short"])
        elif name=="المنشورات":
            content.controls=section(name,[x for x in items if x.get("kind")=="post"])
        elif name=="المحفوظات":
            content.controls=section(name,[x for x in items if x.get("id") in data["saved"]])
        elif name=="السجل":
            content.controls=section(name,[x for ident in data["history"] for x in items if x.get("id")==ident])
        else:
            content.controls=[
                ft.Text("المزيد",size=20,weight=ft.FontWeight.BOLD,color=TEXT),
                ft.Container(bgcolor=CARD,border_radius=16,padding=8,content=ft.Column([
                    ft.ListTile(leading=ft.Icon(ft.Icons.BOOKMARK,color=BERRY),title=ft.Text("المحفوظات"),on_click=lambda e:go("المحفوظات")),
                    ft.ListTile(leading=ft.Icon(ft.Icons.HISTORY,color=BERRY),title=ft.Text("سجل المشاهدة"),on_click=lambda e:go("السجل")),
                    ft.ListTile(leading=ft.Icon(ft.Icons.LIVE_TV,color=BERRY),title=ft.Text("البثوث المباشرة"),on_click=live_check),
                    ft.ListTile(leading=ft.Icon(ft.Icons.CALENDAR_MONTH,color=BERRY),title=ft.Text("مواقيت الصلاة"),on_click=prayer_times),
                    ft.ListTile(leading=ft.Icon(ft.Icons.AUTO_AWESOME,color=BERRY),title=ft.Text("ذكرني بذكر الله"),on_click=adhkar),
                    ft.ListTile(leading=ft.Icon(ft.Icons.DIRECTIONS_CAR,color=BERRY),title=ft.Text("لعبة السيارات"),on_click=game),
                    ft.ListTile(leading=ft.Icon(ft.Icons.CLOUD_SYNC,color=BERRY),title=ft.Text("مزامنة المحتوى السحابي"),on_click=sync_cloud),
                    ft.ListTile(leading=ft.Icon(ft.Icons.ADMIN_PANEL_SETTINGS,color=BERRY),title=ft.Text("إعدادات المالك"),on_click=admin_panel),
                    ft.ListTile(leading=ft.Icon(ft.Icons.INFO_OUTLINE,color=BERRY),title=ft.Text("عن التطبيق"),subtitle=ft.Text("مؤمن تيوب — Python / Flet"))
                ]))
            ]
        page.update()

    def go(name):
        tab["name"]=name;render()

    async def do_search(e):
        await search_click(e)

    search_box.on_submit=do_search
    search_button=ft.IconButton(ft.Icons.SEARCH,icon_color=BERRY,on_click=do_search,tooltip="بحث")
    header=ft.Container(bgcolor=CARD,padding=14,content=ft.Column([
        ft.Row([ft.Container(width=38,height=38,bgcolor=BERRY,border_radius=12,alignment=ft.alignment.center,
            content=ft.Icon(ft.Icons.PLAY_ARROW,color="white",size=28)),
            ft.Column([ft.Text(APP_NAME,size=20,weight=ft.FontWeight.BOLD,color=BERRY),
                       ft.Text("نسخة Python",size=10,color=MUTED)],spacing=0),
            ft.Container(expand=True),ft.IconButton(ft.Icons.SYNC,icon_color=BERRY,on_click=sync_cloud,tooltip="مزامنة")]),
        ft.Row([search_box,search_button])
    ],spacing=8))
    nav=ft.NavigationBar(
        bgcolor=CARD,indicator_color="#F1DDE4",selected_index=0,
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.HOME_OUTLINED,label="الرئيسية"),
            ft.NavigationBarDestination(icon=ft.Icons.VIDEO_LIBRARY_OUTLINED,label="الفيديوهات"),
            ft.NavigationBarDestination(icon=ft.Icons.SLOW_MOTION_VIDEO,label="Shorts"),
            ft.NavigationBarDestination(icon=ft.Icons.DYNAMIC_FEED_OUTLINED,label="المنشورات"),
            ft.NavigationBarDestination(icon=ft.Icons.MORE_HORIZ,label="المزيد")
        ],
        on_change=lambda e:go(["الرئيسية","الفيديوهات","Shorts","المنشورات","المزيد"][e.control.selected_index])
    )
    page.add(ft.Column([
        header,
        ft.Container(content=content,expand=True,padding=14),
        ft.Row([ft.Container(expand=True),ft.FloatingActionButton(icon=ft.Icons.ADD,bgcolor=BERRY,foreground_color="white",on_click=add_content)],padding=ft.padding.only(left=16,right=16,bottom=4)),
        nav,
        ft.Container(content=cloud_label,padding=ft.padding.only(left=14,right=14,bottom=4))
    ],expand=True,spacing=0))
    render()
    if SUPABASE_URL and SUPABASE_KEY:
        page.run_task(sync_cloud)

if __name__ == "__main__":
    ft.app(target=main)
